# app.py — tiny weather app with nicer UI
from flask import Flask, request, render_template_string
import requests

app = Flask(__name__)
GEOCODE = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST = "https://api.open-meteo.com/v1/forecast"

T = """<!doctype html><meta charset="utf-8">
<title>Tiny Weather</title>
<style>
  body {
    font-family: 'Segoe UI', sans-serif;
    margin: 0;
    background: linear-gradient(135deg, #74ebd5, #9face6);
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
  }
  .container {
    background: #fff;
    padding: 30px;
    border-radius: 12px;
    box-shadow: 0 8px 20px rgba(0,0,0,0.15);
    text-align: center;
    width: 320px;
  }
  h3 {
    margin-bottom: 20px;
    color: #333;
  }
  form {
    margin-bottom: 15px;
    display: flex;
    justify-content: center;
  }
  input {
    padding: 10px;
    border: 1px solid #ddd;
    border-radius: 8px;
    width: 70%;
    outline: none;
    transition: border 0.2s;
  }
  input:focus {
    border: 1px solid #74ebd5;
  }
  button {
    padding: 10px 15px;
    margin-left: 8px;
    background: #74ebd5;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
  }
  button:hover {
    background: #5dcfbd;
  }
  .out {
    margin-top: 15px;
    padding: 12px;
    background: #f9fafb;
    border: 1px solid #eee;
    border-radius: 8px;
    font-weight: bold;
    color: #444;
  }
  .error {
    color: #d9534f;
    font-weight: bold;
  }
</style>

<div class="container">
  <h3>🌤 Tiny Weather</h3>
  <form method="post">
    <input name="city" placeholder="Enter city" required value="{{city or ''}}">
    <button>Show</button>
  </form>
  {% if err %}<div class="out error">⚠️ {{err}}</div>{% endif %}
  {% if out %}<div class="out">{{out}}</div>{% endif %}
</div>
"""

def geocode(city):
    r = requests.get(GEOCODE, params={"name":city,"count":1}, timeout=8).json()
    if r.get("results"):
        p = r["results"][0]
        return p["latitude"], p["longitude"], p["name"], p.get("country","")
    return None

def weather(lat, lon):
    r = requests.get(FORECAST, params={
        "latitude":lat, "longitude":lon, "current_weather":True
    }, timeout=8).json()
    return r.get("current_weather")

@app.route("/", methods=["GET","POST"])
def index():
    out = err = city = None
    if request.method=="POST":
        city = request.form.get("city","").strip()
        if city:
            g = geocode(city)
            if not g:
                err = "City not found."
            else:
                lat, lon, name, country = g
                w = weather(lat, lon)
                if not w:
                    err = "Weather unavailable."
                else:
                    out = f"{name}, {country}: {w.get('temperature')}°C | Wind {w.get('windspeed')} km/h"
    return render_template_string(T, out=out, err=err, city=city)

if __name__=="__main__":
    app.run(debug=True)
